if (GetLocale() == "deDE") then
	local RTB = LibStub( "LibBabble-Boss-3.0" ):GetLookupTable();
  local RTL = LibStub("AceLocale-3.0"):GetLocale("CT_RaidTracker")
	CT_RaidTracker_lang_BossKills = {
		-- Ulduar
		["Es scheint, als w\195\164re mir eine klitzekleine Fehlkalkulation unterlaufen. Ich habe zugelassen, dass das Scheusal im Gef\195\164ngnis meine Prim\195\164rdirektive \195\188berschreibt. Alle Systeme nun funktionst\195\188chtig."] = RTB["Mimiron"],
--		["I...have...failed..."] = RTB["Ignis the Furnace Master"],
		["Seine Macht \195\188ber mich beginnt zu schwinden. Endlich kann ich wieder klar sehen. Ich danke Euch, Helden."] = RTB["Freya"],
		["Senkt Eure Waffen! Ich ergebe mich!"] = RTB["Thorim"],
		["Ich... bin von ihm befreit... endlich."] = RTB["Hodir"],
--		["Meister, sie kommen..."] = RTB["Kologarn"],
--		["Ihr seid b\195\182se... Spielzeuge... b\195\182\195\182\195\182\195\182\195\182se..."] = RTB["XT-002 Deconstructor"],
--		["Mwa-ha-ha-ha! Oh, what horrors await you?"] = RTB["General Vezax"],
		["Your fate is sealed. The end of days is finally upon you and ALL who inhabit this miserable little seedling! Uulwi ifis halahs gag erh'ongg w'ssh."] = RTB["Yogg-Saron"],
		["Ihr habt den Eisernen Rat besiegt und das Archivum ge\195\182ffnet! Gut gemacht, Leute!"] = RTB["Assembly of Iron"],
		["Ihr habt den Eisernen Rat besiegt und das Archivum ge\195\182ffnet!  Gut gemacht, Leute!"] = RTB["Assembly of Iron"],
		["Unm\195\182glich..."] = RTB["Assembly of Iron"], -- Iron Council Hardmode / Steelbreaker will triger by LK to
		["Ihr lauft geradewegs in den Schlund des Wahnsinns!"] = RTB["Assembly of Iron"], -- Iron Council Normalmode / Brundir last
--		["What have you gained from my defeat? You are no less doomed, mortals!"] = RTB["Assembly of Iron"], -- Iron Council Semimode / Molgeim last
		["Ich sah Welten umh\195\188llt von den Flammen der Sch\195\182pfer, sah ohne einen Hauch von Trauer ihre Bewohner vergehen. Ganze Planetensysteme geboren und vernichtet, w\195\164hrend Eure sterblichen Herzen nur einmal schlagen. Doch immer war mein Herz kalt... ohne Mitgef\195\188hl. Ich - habe - nichts - gef\195\188hlt. Millionen, Milliarden Leben verschwendet. Trugen sie alle dieselbe Beharrlichkeit in sich, wie Ihr? Liebten sie alle das Leben so sehr, wie Ihr es tut?"] = RTB["Algalon the Observer"],
		-- Ulduar
		-- Trial of the Crusader
		["Die Gei\195\159el kann nicht aufgehalten werden..."] = RTB["The Twin Val'kyr"],
		["Ich habe Euch entt\195\164uscht, Meister..."] = RTB["Anub'arak"], ---notwork
		["Champions der Allianz"] = RTB["Faction Champions"],
		["EHRE DER ALLIANZ!"] = RTB["Faction Champions"],
		["Ein tragischer Sieg. Wir wurden schw\195\164cher durch die heutigen Verluste. Wer au\195\159er dem Lichk\195\182nig profitiert von solchen Torheiten? Gro\195\159e Krieger gaben ihr Leben. Und wof\195\188r? Die wahre Bedrohung erwartet uns noch - der Lichk\195\182nig erwartet uns alle im Tod."] = RTB["Faction Champions"],
		-- Trial of the Crusader
		-- Icecrown Citadel
		["Sagt nicht, ich h\195\164tte Euch nicht gewarnt, Ihr Schurken! Vorw\195\164rts, Br\195\188der und Schwestern!"] = RTB["Icecrown Gunship Battle"],
		["Die Allianz wankt. Vorw\195\164rts zum Lichk\195\182nig!"] = RTB["Icecrown Gunship Battle"], -- Gunship Horde
		["Meine K\195\182nigin, sie... kommen."] = RTB["Blood Prince Council"], -- Blood Prince Council
		["ICH BIN GEHEILT! Ysera, erlaubt mir, diese \195\188blen Kreaturen zu beseitigen!"] = RTB["Valithria Dreamwalker"],
    -- Icecrown Citadel

    -- Ruby Sanctum
		["Genie\195\159t euren Sieg, Sterbliche, denn es war euer letzter. Bei der R\195\188ckkehr des Meisters wird diese Welt brennen!"] = RTB["Halion"],
-- may be neds to be change
		["Unm\195\182glich! Haltet ein, Sterbliche... Ich gebe auf! Ich gebe auf!"] = RTB["Majordomo Executus"],
--	CT_RaidTracker_lang_BossKills_Ignore_Razorgore_Yell = "Ich bin frei! Dieses Ger\195\164t wird mich niemals wieder qu\195\164len!";
		["Als sich der Fluch, der auf den T\195\188ren der Halle der Spiele lastete, l\195\182st, beginnen die Mauern von Karazhan zu beben."] = RTB["Chess Event"],
		["Oh willkommener Dolch! Dies werde deine Scheide. Roste da und lass mich sterben!"] = RTB["Julianne"],
		["Ich bin niemals auf der... Verlierer... seite!"] = RTB["Sathrovarr the Corruptor"],

--	CT_RaidTracker_lang_BossKills_Ignore_Julianne_Yell = "Ich komme, Romulo! Oh... dies trink' ich dir!";
--	CT_RaidTracker_lang_BossKills_Ignore_Romulo_Yell = "Und du l\195\164chelst zu dem Streich, der mich ermordet.";
-- Four Winds
    ["Das Konklave des Windes hat sich aufgelöst. Euer ehrenvolles Betragen sowie eure Entschlossenheit haben euch das Recht verschafft, mir in der Schlacht gegenüberzutreten, Sterbliche. Ich erwarte Euren Angriff auf meiner Plattform! Kommt!"] = RTB["Conclave of Wind"], -- Conclave of Wind
    
-- Firelands
        ["Zu fr\195\188h!... Ihr kommt zu fr\195\188h..."] = RTB["Ragnaros"],

-- Dragon Soul
    ["Exzellente Arbeit. Das Feuer meines Herzens gl\195\188ht mit einer nie zuvor dagewesenen Reinheit. Ich werde jeden Funken in die Drachenseele leiten."] = RTB["Madness of Deathwing"],
    ["Es ist an der Zeit. Ich werde alles tun, um die Schicksalsstr\195\164nge hier und jetzt um die Drachenseele zu binden. Was geschehen wird, kann NIEMALS r\195\188ckg\195\164ngig gemacht werden."] = RTB["Madness of Deathwing"],
    ["Wir sind einen Schritt weiter. Ich gebe der Drachenseele jetzt die unbegreifliche, \195\188berweltliche Macht des Smaragdgr\195\188nen Traums."] = RTB["Madness of Deathwing"],
    ["Gut gemacht! Ich werde den Manafluss neu ausrichten und die Drachenseele mit meiner arkanen Macht f\195\188llen."] = RTB["Madness of Deathwing"],
    
    -- BF
    ["Ich hasse Euch alle!"] = RTL["Alizabal"],
    
    };
    
    
end;