if (GetLocale() == "esES" or (GetLocale() == "esMX")) then
	local RTB = LibStub( "LibBabble-Boss-3.0" ):GetLookupTable();

	CT_RaidTracker_lang_BossKills = {
		-- Ulduar
		[" Parece que he cometido un leve error de c\195\161lculo. He permitido que mi mente se corrompiera demonio en la preision, sobrescribiendo mi directiva principal. Todos mis sistemas parecen funcionar de nuevo. Evidente."] = RTB["Mimiron"],
		["He...fallado"] = RTB["Ignis the Furnace Master"],
		["Su control sobre mi se ha terminado. Puedo ver claramente una vez m\195\161s. Gracias, heroes."] = RTB["Freya"],
		["Detener vuestras manos! Yo cedo!"] = RTB["Thorim"],
		["Yo...Yo he sido liberado de su alcance! Finalmente!"] = RTB["Hodir"],
--      ["Maestro, ya vienen..."] = RTB["Kologarn"],
--      ["Juguetes... Malos... Muy... Maaaalos!"] = RTB["XT-002 Deconstructor"],
--      ["Mwa-ha-ha-ha! Oh, qu\195\169 horrores os esperan?"] = RTB["General Vezax"],
		["Tu destino est\195\161 sellado. El final de los d\195\173as finalmente ha llegado sobre ti y todos los que habitan esta miserable tierra!"] = RTB["Yogg-Saron"],
		["Habeis derrotado a la Asamblea de Hierro y desbloqueado el Archivum! Bien hecho, chicos!"] = RTB["Assembly of Iron"],
		-- Ulduar
		-- Trial of the Crusader
		["El Azote no puede ser detenido..."] = RTB["The Twin Val'kyr"],
		["Te he fallado, maestro..."] = RTB["Anub'arak"],
		["Campeones de Facci\195\179n GRITAN"] = RTB["Faction Champions"], -- Yell for faction champions still missing
		-- Trial of the Crusader
		-- Icecrown Citadel
		["The Alliance falter. Onward to the Lich King!"] = RTB["Icecrown Gunship Battle"], -- Gunship Battle Horde yell, unknown.
		["\194\161No dig\195\161is que no lo avis\195\169, sinverg\195\188enzas! Adelante, hermanos."] = RTB["Icecrown Gunship Battle"],
		["Yo... Soy... Libre"] = RTB["Deathbringer Saurfang"], -- Not confirmed.
		-- Icecrown Citadel
	};

end;