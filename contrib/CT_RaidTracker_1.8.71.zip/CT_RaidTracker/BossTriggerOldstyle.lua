﻿local RTZ = LibStub( "LibBabble-Zone-3.0" ):GetLookupTable();
local RTB = LibStub( "LibBabble-Boss-3.0" ):GetLookupTable();
local RTL = LibStub("AceLocale-3.0"):GetLocale("CT_RaidTracker")
CT_RaidTracker_Data = {};
CT_RaidTracker_TableNames = {};

CT_RaidTracker_Translation_Complete = false;

CT_RaidTracker_Zones = {
	"----Cata----",
	RTL["Blackwing Descent"],
	RTL["Baradin Hold"],
	RTL["Throne of the Four Winds"],
	RTL["The Bastion of Twilight"],
	"----LK----",
	RTZ["Naxxramas"],
	RTZ["The Eye of Eternity"],
	RTZ["The Obsidian Sanctum"],
	RTZ["Ulduar"],
	RTZ["Vault of Archavon"],
	RTZ["Trial of the Crusader"],
--	RTZ["Trial of the Grand Crusader"],
	RTZ["Onyxia's Lair"],
	RTZ["Icecrown Citadel"],
	RTZ["The Ruby Sanctum"],
	"----Vanilla----",
	RTZ["Molten Core"],
	RTZ["Blackwing Lair"],
	RTZ["Zul'Gurub"],
	RTZ["Onyxia's Lair"],
	RTZ["Ruins of Ahn'Qiraj"],
	RTZ["Temple of Ahn'Qiraj"],
	"----TBC----",
	RTZ["Karazhan"],
	RTZ["Gruul's Lair"],
	RTZ["Magtheridon's Lair"],
	RTZ["Serpentshrine Cavern"],
--	RTZ["Caverns Of Time"],
	RTZ["Tempest Keep"],
	RTZ["Black Temple"],
	RTL["Battle of Mount Hyjal"],
	RTZ["Zul'Aman"],
	RTZ["Sunwell Plateau"],
--[[	"----test----",
	RTZ["Magisters' Terrace"],	
	RTZ["The Shattered Halls"],
	RTZ["Ragefire Chasm"], ]]
	" ",
	"Worldboss",

	};

CT_RaidTracker_Bosses = {
--cata	needs to wait to translation of blizzard
	[RTL["Blackwing Descent"]] = {
		RTL["Magmaul"],					-- Magmaw missing
		RTL["Omnitron Defense System"],		--[42180]	-- ID of Toxitron   - Omnitron Defense System may need bossyell
		RTL["Maloriak"],					--[41378]
		RTL["Atramedes"],				--[41442] 
		RTL["Chimaeron"],				--[43296]
		RTL["Nefarian"],					--[41376] 
	},

	[RTL["Throne of the Four Winds"]]= {
		RTL["Conclave of Wind"],			--[45871]	-- ID of Nezir      - Conclave of Wind may need a bossyell (mobs are probably too far away to each other)
		RTL["Al'Akir"],					--[46753]
	},

	[RTL["The Bastion of Twilight"]] = {
		RTL["Valiona and Theralion"],			--[45992]	-- ID of Valiona    - Valiona & Theralion - Twin drakes with shared health pool - may need boss yell
		RTL["Halfus Wyrmbreaker"],			--[44600]
		RTL["Ascendant Council"],			--[43735]	-- ID of Elementium Monstrosity
		RTL["Cho'gall"],					--[43324] 
	},

	[RTL["Baradin Hold"]] = {
	RTL["Argaloth"],	
	},
--LK		
	[RTZ["The Eye of Eternity"]] = {
		RTB["Malygos"],
	},

	[RTZ["The Obsidian Sanctum"]] = {
		RTB["Sartharion"],
		"Sartharion + 1 Drake",
		"Sartharion + 2 Drakes",
		"Sartharion + 3 Drakes",
	},

	[RTZ["Vault of Archavon"]] = {
		RTB["Archavon the Stone Watcher"],
		RTB["Emalon the Storm Watcher"],
		RTB["Koralon the Flame Watcher"],
		RTB["Toravon the Ice Watcher"],
	},

	[RTZ["Naxxramas"]] = {
		RTB["Anub'Rekhan"],
		RTB["The Four Horsemen"],
		RTB["Gluth"],
		RTB["Gothik the Harvester"],
		RTB["Grand Widow Faerlina"],
		RTB["Grobbulus"],
		RTB["Heigan the Unclean"],
		RTB["Instructor Razuvious"],
		RTB["Kel'Thuzad"],
		RTB["Loatheb"],
		RTB["Maexxna"],
		RTB["Noth the Plaguebringer"],
		RTB["Patchwerk"],
		RTB["Sapphiron"],
		RTB["Thaddius"],
	},
	[RTZ["Ulduar"]] = {
		RTB["Algalon the Observer"],
		RTB["Auriaya"],
		RTB["Flame Leviathan"],
		RTB["Freya"],
		RTB["General Vezax"],
		RTB["Hodir"],
		RTB["Ignis the Furnace Master"],
		RTB["Kologarn"],
		RTB["Mimiron"],
		RTB["Razorscale"],
		RTB["Assembly of Iron"],
		RTB["Thorim"],
		RTB["XT-002 Deconstructor"],
		RTB["Yogg-Saron"],
	},
	[RTZ["Trial of the Crusader"]] = {
		RTB["Anub'arak"],
		RTB["Faction Champions"],
		RTB["Lord Jaraxxus"],
		RTB["The Beasts of Northrend"],
		RTB["The Twin Val'kyr"],
	},
--	[RTZ["Trial of the Grand Crusader"]] = {
--		RTB["Anub'arak"],
--		RTB["Faction Champions"],
--		RTB["Lord Jaraxxus"],
--		RTB["Northrend Beasts"],
--		RTB["Twin Val'kyr"],
--		RTB["32trophy"],
--	},
	[RTZ["Onyxia's Lair"]] = {
		RTB["Onyxia"],
	},
	[RTZ["Icecrown Citadel"]] = {
		RTB["Lord Marrowgar"],
		RTB["Lady Deathwhisper"],
		RTB["Icecrown Gunship Battle"],
		RTB["Deathbringer Saurfang"],
		RTB["Festergut"],
		RTB["Rotface"],
		RTB["Professor Putricide"],
		RTB["Blood Prince Council"],
		RTB["Blood-Queen Lana'thel"],
		RTB["Valithria Dreamwalker"],
		RTB["Sindragosa"],
		RTB["The Lich King"],

		"Token-Trash",

	},

	[RTZ["The Ruby Sanctum"]] = {
		RTB["Halion"],
--		"Halion Hardmode",
	},

	["Worldboss"] = {
		RTB["Lord Kazzak"],
		RTB["Azuregos"],

--		RTB["Highlord Kruul"],	
		RTB["Doom Lord Kazzak"],
		RTB["Doomwalker"],

		RTB["Ysondre"],
		RTB["Taerar"],
		RTB["Emeriss"],
		RTB["Lethon"],
	},
--bc and older	
	[RTZ["Karazhan"]] = {
		RTB["Attumen the Huntsman"],
		RTB["Moroes"],
		RTB["Maiden of Virtue"],
		RTB["Opera Event"], --[[= {
			"Oz",
			"The Crone",
			"The Big Bad Wolf",
			"Romulo and Julianne",
		},]]
		RTB["The Curator"],
		RTB["Terestian Illhoof"],
		RTB["Shade of Aran"],
		RTB["Chess Event"],
		RTB["Prince Malchezaar"],

		RTB["Netherspite"],
		RTB["Nightbane"],
		RTB["Rokad the Ravager"],
		RTB["Hyakiss the Lurker"],
		RTB["Shadikith the Glider"],
--		RTB["Echo of Medivh"],
--		RTB["Image of Medivh"],
	},
	[RTZ["Gruul's Lair"]] = {
		RTB["High King Maulgar"],
		RTB["Gruul the Dragonkiller"],
	},
	[RTZ["Magtheridon's Lair"]] = {
		RTB["Magtheridon"],
	},
	[RTZ["Serpentshrine Cavern"]] = {
		RTB["Hydross the Unstable"],
		RTB["The Lurker Below"],
		RTB["Leotheras the Blind"],
		RTB["Fathom-Lord Karathress"],
		RTB["Morogrim Tidewalker"],
		RTB["Lady Vashj"],
	},
--[[	[RTZ["Caverns Of Time"] ] = {
		"Unknown",
	},]]
	[RTZ["Black Temple"]] = {
		RTB["High Warlord Naj'entus"],
		RTB["Supremus"],
		RTB["Gurtogg Bloodboil"],
		RTB["Teron Gorefiend"],
		RTB["Shade of Akama"],
		RTB["Reliquary of Souls"],
		RTB["Mother Shahraz"],
		RTB["Illidari Council"],
		RTB["Illidan Stormrage"],
	},
	[RTZ["Tempest Keep"]] = {
		RTB["Al'ar"],
		RTB["High Astromancer Solarian"],
		RTB["Void Reaver"],
		RTB["Kael'thas Sunstrider"],
	},
	[RTL["Battle of Mount Hyjal"]] = {
		RTB["Rage Winterchill"],
		RTB["Anetheron"],
		RTB["Kaz'rogal"],
		RTB["Azgalor"],
		RTB["Archimonde"],
	},
	[RTZ["Zul'Aman"]] = {
		RTB["Nalorakk"],
		RTB["Akil'zon"],
		RTB["Jan'alai"],
		RTB["Halazzi"],
--		RTB["Witch Doctor Zum'rah"],
		RTB["Hex Lord Malacrass"],
		RTB["Zul'jin"],
	},
	[RTZ["Sunwell Plateau"]] = {
		RTB["Kalecgos"],
		RTB["Sathrovarr the Corruptor"],
		RTB["Brutallus"],
		RTB["Felmyst"],
		RTB["The Eredar Twins"],
		RTB["Entropius"],
		RTB["Kil'jaeden"],
	},
	[RTZ["Molten Core"]] = {
		RTB["Lucifron"],
		RTB["Magmadar"],
		RTB["Gehennas"],
		RTB["Garr"],
		RTB["Baron Geddon"],
		RTB["Shazzrah"],
		RTB["Sulfuron Harbinger"],
		RTB["Golemagg the Incinerator"],
		RTB["Majordomo Executus"],
		RTB["Ragnaros"],
	},
	[RTZ["Blackwing Lair"]] = {
		RTB["Razorgore the Untamed"],
		RTB["Vaelastrasz the Corrupt"],
		RTB["Broodlord Lashlayer"],
		RTB["Firemaw"],
		RTB["Ebonroc"],
		RTB["Flamegor"],
		RTB["Chromaggus"],
		RTB["Nefarian"],
	},
	[RTZ["Zul'Gurub"]] = {
		RTB["High Priestess Jeklik"],
		RTB["High Priest Venoxis"],
		RTB["High Priestess Mar'li"],
		RTB["High Priest Thekal"],
		RTB["High Priestess Arlokk"],
		RTB["Hakkar"],
		RTB["Bloodlord Mandokir"],
		RTB["Jin'do the Hexxer"],
		RTB["Gahz'ranka"],
		RTB["Hazza'rah"],
		RTB["Gri'lek"],
		RTB["Renataki"],
		RTB["Wushoolay"],
	},
	[RTZ["Temple of Ahn'Qiraj"]] = {
		RTB["The Prophet Skeram"],
		RTB["Fankriss the Unyielding"],
		RTB["Battleguard Sartura"],
		RTB["Princess Huhuran"],
		RTB["The Twin Emperors"],
		RTB["C'Thun"],
		RTB["Vem"],
		RTB["Princess Yauj"],
		RTB["Lord Kri"],
		RTB["Viscidus"],
		RTB["Ouro"],
	},
	[RTZ["Ruins of Ahn'Qiraj"]] = {
		RTB["Kurinnaxx"],
		RTB["General Rajaxx"],
		RTB["Ayamiss the Hunter"],
		RTB["Moam"],
		RTB["Buru the Gorger"],
		RTB["Ossirian the Unscarred"],
	},
--[[----------------------Test Zone----------------------
	[RTZ["Ragefire Chasm"] = {
      		RTB["Oggleflint"],
		RTB["Taragaman the Hungerer"],
      		RTB["Jergosh the Invoker"],
      		RTB["Bazzalan"],
   	},

	[RTZ["Magisters' Terrace"] = {	
    		RTB["Selin Fireheart"],
		RTB["Vexallus"],
		RTB["Priestess Delrissa"],
		RTB["Kael'thas Sunstrider"],
	},
	[RTZ["The Shattered Halls"] = {
		RTB["Grand Warlock Nethekurse"],
		RTB["Blood Guard Porung"],
		RTB["Warbringer O'mrogg"],
		RTB["Warchief Kargath Bladefist"],
	},
]]
	["Administration"] = {
		"Track Members",
		"Punctuality",
		"Fault",
	},
	--Trash
	["Trash mob"] = 1,
};

CT_RaidTracker_ZoneTriggers = {

	[RTL["Blackwing Descent"]] = "Blackwing Descent",
	[RTL["Baradin Hold"]] = "Baradin Hold",
	[RTL["Throne of the Four Winds"]] = "Throne of the Four Winds",
	[RTL["The Bastion of Twilight"]] = "The Bastion of Twilight",

-- WotLK
	[RTZ["The Eye of Eternity"]] = "The Eye of Eternity",
	[RTZ["The Obsidian Sanctum"]] = "The Obsidian Sanctum",
	[RTZ["Vault of Archavon"]] = "Vault of Archavon",
	[RTZ["Naxxramas"]] = "Naxxramas",
	[RTZ["Ulduar"]] = "Ulduar",
	[RTZ["Trial of the Crusader"]] = "Trial of the Crusader",
--	[RTZ["Trial of the Grand Crusader"]] = "Trial of the Grand Crusader",
	[RTZ["Onyxia's Lair"]] = "Onyxia's Lair",
	[RTZ["Icecrown Citadel"]] = "Icecrown Citadel",
	[RTZ["The Ruby Sanctum"]] = "The Ruby Sanctum",

	[RTZ["Molten Core"]] = "Molten Core",
	[RTZ["Blackwing Lair"]] = "Blackwing Lair",
	[RTZ["Zul'Gurub"]] = "Zul'Gurub",
	[RTZ["Ruins of Ahn'Qiraj"]] = "Ruins of Ahn'Qiraj",
	[RTZ["Temple of Ahn'Qiraj"]] = "Temple of Ahn'Qiraj",
	-- TBC
	[RTZ["Karazhan"]] = "Karazhan",
	[RTZ["Gruul's Lair"]] = "Gruul's Lair",
	[RTZ["Magtheridon's Lair"]] = "Magtheridon's Lair",
	[RTZ["Serpentshrine Cavern"]] = "Serpentshrine Cavern",
--	[RTZ["Caverns Of Time"]] = "Caverns Of Time",
	[RTZ["Black Temple"]] = "Black Temple",
	[RTZ["Tempest Keep"]] = "Tempest Keep",
	[RTL["Battle of Mount Hyjal"]] = "Battle of Mount Hyjal",
	[RTZ["Zul'Aman"]] = "Zul'Aman",
	[RTZ["Sunwell Plateau"]] = "Sunwell Plateau",
	--test

	[RTZ["Magisters' Terrace"]] = "Magisters' Terrace",
	[RTZ["The Shattered Halls"]] = "The Shattered Halls",

-- WotLK
};
CT_RaidTracker_BossUnitTriggers = {
-- Wotlk

--Cata bosses
		[RTL["Argaloth"]] = "Argaloth",					--[47120]
		-- Blackwing Descent
		[RTL["Magmaul"]] = "Magmaul",					-- Magmaw missing
		[RTL["Omnitron Defense System"]] = "Omnitron Defense System",		--[42180]	-- ID of Toxitron   - Omnitron Defense System may need bossyell
		[RTL["Maloriak"]] = "Maloriak",					--[41378]
		[RTL["Atramedes"]] = "Atramedes",				--[41442] 
		[RTL["Chimaeron"]] = "Chimaeron",				--[43296]
		[RTL["Nefarian"]] = "Nefarian",					--[41376] 

		-- The Bastion of Twilight
		[RTL["Valiona and Theralion"]] = "Valiona and Theralion",		--[45992]	-- ID of Valiona    - Valiona & Theralion - Twin drakes with shared health pool - may need boss yell
		[RTL["Halfus Wyrmbreaker"]] = "Halfus Wyrmbreaker",			--[44600]
		[RTL["Ascendant Council"]] = "Ascendant Council",			--[43735]	-- ID of Elementium Monstrosity
		[RTL["Cho'gall"]] = "Cho'gall",					--[43324] 

		-- Throne of the Four Winds
		[RTL["Conclave of Wind"]] = "Conclave of Wind",			--[45871]	-- ID of Nezir      - Conclave of Wind may need a bossyell (mobs are probably too far away to each other)
		[RTL["Al'Akir"]] = "Al'Akir",					--[46753]
		--end of cata

		[RTB["Malygos"]] = "Malygos",

		-- Obsidian Sanctum
		[RTB["Sartharion"]] = "Sartharion",

		-- Vault of Archavon
		[RTB["Archavon the Stone Watcher"]] = "Archavon the Stone Watcher",
		[RTB["Emalon the Storm Watcher"]] = "Emalon the Storm Watcher",
		[RTB["Koralon the Flame Watcher"]] = "Koralon the Flame Watcher",
		[RTB["Toravon the Ice Watcher"]] = "Toravon the Ice Watcher",
		-- Vault of Archavon


	-- Naxxramas
	[RTB["Patchwerk"]] = "Patchwerk",
	[RTB["Grobbulus"]] = "Grobbulus",
	[RTB["Gluth"]] = "Gluth",
	[RTB["Thaddius"]] = "Thaddius",
	[RTB["Instructor Razuvious"]] = "Instructor Razuvious",
	[RTB["Gothik the Harvester"]] = "Gothik the Harvester",

	[RTB["Noth the Plaguebringer"]] = "Noth the Plaguebringer",
	[RTB["Heigan the Unclean"]] = "Heigan the Unclean",
	[RTB["Loatheb"]] = "Loatheb",
	[RTB["Anub'Rekhan"]] = "Anub'Rekhan",
	[RTB["Grand Widow Faerlina"]] = "Grand Widow Faerlina",
	[RTB["Maexxna"]] = "Maexxna",
	[RTB["Sapphiron"]] = "Sapphiron",
	[RTB["Kel'Thuzad"]] = "Kel'Thuzad",
--	[RTB["Fangnetz"] = "IGNORE",
--	[RTB["Verstrahlter Br\195\188hschleimer"] = "IGNORE",

--	[RTB["Crypt Guard"] = "IGNORE",
--	[RTB["Grobbulus Cloud"] = "IGNORE",
--	[RTB["Deathknight Understudy"] = "IGNORE",
--	[RTB["Maggot"] = "IGNORE",
---	[RTB["Maexxna Spiderling"] = "IGNORE",
--	[RTB["Plagued Warrior"] = "IGNORE",
--	[RTB["Zombie Chow"] = "IGNORE",
--	[RTB["Corpse Scarab"] = "IGNORE",
--	[RTB["Naxxramas Follower"] = "IGNORE",
--	[RTB["Naxxramas Worshipper"] = "IGNORE",
--	[RTB["Web Wrap"] = "IGNORE",
---	[RTB["Fallout Slime"] = "IGNORE",
--	[RTB["Diseased Maggot"] = "IGNORE",
--	[RTB["Rotting Maggot"] = "IGNORE",
--	[RTB["Living Poison"] = "IGNORE",
--	[RTB["Spore"] = "IGNORE",
	-- 4 Horsemen
	--["Highlord Mograine"]] = "Four Horsemen", -- From old Naxx
--	[RTB["Baron Rivendare"] = "IGNORE",
--	[RTB["Thane Korth'azz"] = "IGNORE",
--	[RTB["Lady Blaumeux"] = "IGNORE",
--	[RTB["Sir Zeliek"] = "IGNORE",
	[RTB["The Four Horsemen"]] = "The Four Horsemen",

	-- Ulduar
	[RTB["Hodir"]] = "Hodir",
--	[RTB["Stormcaller Brundir"] = "IGNORE", -- The Assembly of Iron
	[RTB["Thorim"]] = "Thorim",
--	[RTB["Steelbreaker"] = "IGNORE", -- The Assembly of Iron
	[RTB["Freya"]] = "Freya",
--	[RTB["Runemaster Molgeim"] = "IGNORE", -- The Assembly of Iron
	[RTB["Assembly of Iron"]] = "Assembly of Iron", -- Dummy
	[RTB["Flame Leviathan"]] = "Flame Leviathan",
	[RTB["Ignis the Furnace Master"]] = "Ignis the Furnace Master",
	[RTB["Razorscale"]] = "Razorscale",
	[RTB["General Vezax"]] = "General Vezax",
	[RTB["Yogg-Saron"]] = "Yogg-Saron",
	[RTB["XT-002 Deconstructor"]] = "XT-002 Deconstructor",
	[RTB["Auriaya"]] = "Auriaya",
	[RTB["Kologarn"]] = "Kologarn",
	[RTB["Mimiron"]] = "Mimiron",
	[RTB["Algalon the Observer"]] = "Algalon the Observer",
	-- Ulduar

	-- Trial of the Crusader
	[RTB["Icehowl"]] = "The Beasts of Northrend",
	[RTB["Lord Jaraxxus"]] = "Lord Jaraxxus",
--	[RTB["Fjola Lightbane"] = "IGNORE",
--	[RTB["Edyis Darkbane"] = "IGNORE",
	-- Yell Helper
--	[RTB["The Twin Val'kyr"]] = "The Twin Val'kyr",
	[RTB["Anub'arak"]] = "Anub'arak",
	[RTB["Faction Champions"]] = "Faction Champions",
	-- Trial of the Crusader

	-- Onyxia's Lair
	[RTB["Onyxia"]] = "Onyxia",
--	[RTB["Onyxian Warder"] = "IGNORE",
--	[RTB["Onyxian Whelp"] = "IGNORE",
	-- Onyxia's Lair

	-- Icecrown Citadel"
	[RTB["Lord Marrowgar"]] = "Lord Marrowgar",
	[RTB["Lady Deathwhisper"]] = "Lady Deathwhisper",
	[RTB["Icecrown Gunship Battle"]] = "Icecrown Gunship Battle",
	[RTB["Deathbringer Saurfang"]] = "Deathbringer Saurfang",
	[RTB["Festergut"]] = "Festergut",
	[RTB["Rotface"]] = "Rotface",
	[RTB["Professor Putricide"]] = "Professor Putricide",
	[RTB["Blood Prince Council"]] = "Blood Prince Council",
	[RTB["Blood-Queen Lana'thel"]] = "Blood-Queen Lana'thel",
	[RTB["Valithria Dreamwalker"]] = "Valithria Dreamwalker",
	[RTB["Sindragosa"]] = "Sindragosa",
	[RTB["The Lich King"]] = "The Lich King",
	-- Icecrown Citadel"


	-- The Ruby Sanctum"]
		[RTB["Halion"]] = "Halion",
		-- ["Halion Hardmode"]] = "Halion Hardmode", -- Dummy do not change!
--		[RTB["Baltharus the Warborn"] = "IGNORE",
--		[RTB["General Zarithrian"] = "IGNORE",
--		[RTB["Saviana Ragefire"] = "IGNORE",

-- 		vanilla
		[RTB["Lucifron"]] = "Lucifron",
		[RTB["Magmadar"]] = "Magmadar",
		[RTB["Gehennas"]] = "Gehennas",
		[RTB["Garr"]] = "Garr",
		[RTB["Baron Geddon"]] = "Baron Geddon",
		[RTB["Shazzrah"]] = "Shazzrah",
		[RTB["Sulfuron Harbinger"]] = "Sulfuron Harbinger",
		[RTB["Golemagg the Incinerator"]] = "Golemagg the Incinerator",
		[RTB["Majordomo Executus"]] = "Majordomo Executus", --yell
		[RTB["Ragnaros"]] = "Ragnaros",
--		[RTB["Core Hound"] = "IGNORE",
--		[RTB["Firesworn"] = "IGNORE",
--		[RTB["Core Rager"] = "IGNORE",
--		[RTB["Flamewaker Healer"] = "IGNORE",
--		[RTB["Flamewaker Elite"] = "IGNORE",
--		[RTB["Son of Flame"] = "IGNORE",

		[RTB["Razorgore the Untamed"]] = "Razorgore the Untamed",
		[RTB["Vaelastrasz the Corrupt"]] = "Vaelastrasz the Corrupt",
		[RTB["Broodlord Lashlayer"]] = "Broodlord Lashlayer",
		[RTB["Firemaw"]] = "Firemaw",
		[RTB["Ebonroc"]] = "Ebonroc",
		[RTB["Flamegor"]] = "Flamegor",
		[RTB["Chromaggus"]] = "Chromaggus",
		[RTB["Nefarian"]] = "Nefarian",
		[RTB["Lord Victor Nefarius"]] = "Nefarian",
--		[RTB["Grethok the Controller"] = "IGNORE",
--		[RTB["Blackwing Guardsman"] = "IGNORE",
--		[RTB["Blackwing Legionnaire"] = "IGNORE",
--		[RTB["Blackwing Mage"] = "IGNORE",
--		[RTB["Death Talon Dragonspawn"] = "IGNORE",
--		[RTB["Black Drakonid"] = "IGNORE",
---		[RTB["Blue Drakonid"] = "IGNORE",
--		[RTB["Bronze Drakonid"] = "IGNORE",
--		[RTB["Green Drakonid"] = "IGNORE",
--		[RTB["Red Drakonid"] = "IGNORE",
--		[RTB["Chromatic Drakonid"] = "IGNORE",
--		[RTB["Bone Construct"] = "IGNORE",
--		[RTB["Corrupted Infernal"] = "IGNORE",
--		[RTB["Corrupted Blue Whelp"] = "IGNORE",
--		[RTB["Corrupted Red Whelp"] = "IGNORE",
--		[RTB["Corrupted Green Whelp"] = "IGNORE",
--		[RTB["Corrupted Bronze Whelp"] = "IGNORE",
--		[RTB["Death Talon Hatcher"] = "IGNORE",
--		[RTB["Blackwing Taskmaster"] = "IGNORE",

		[RTB["High Priestess Jeklik"]] = "High Priestess Jeklik",
		[RTB["High Priest Venoxis"]] = "High Priest Venoxis",
		[RTB["High Priestess Mar'li"]] = "High Priestess Mar'li",
		[RTB["High Priest Thekal"]] = "High Priest Thekal",
		[RTB["High Priestess Arlokk"]] = "High Priestess Arlokk",
		[RTB["Hakkar"]] = "Hakkar",
		[RTB["Bloodlord Mandokir"]] = "Bloodlord Mandokir",
		[RTB["Jin'do the Hexxer"]] = "Jin'do the Hexxer",
		[RTB["Gahz'ranka"]] = "Gahz'ranka",
		[RTB["Hazza'rah"]] = "Hazza'rah",
		[RTB["Gri'lek"]] = "Gri'lek",
		[RTB["Renataki"]] = "Renataki",
		[RTB["Wushoolay"]] = "Wushoolay",
--		[RTB["Zulian Prowler"] = "IGNORE",
--		[RTB["Zulian Guardian"] = "IGNORE",
--		[RTB["Parasitic Serpent"] = "IGNORE",
--		[RTB["Spawn of Mar'li"] = "IGNORE",
--		[RTB["Ohgan"] = "IGNORE",
--		[RTB["Frenzied Bloodseeker Bat"] = "IGNORE",
--		[RTB["Poisonous Cloud"] = "IGNORE",


--		[RTB["Onyxia"]] = "Onyxia",
		[RTB["Lord Kazzak"]] = "Lord Kazzak",
		[RTB["Azuregos"]] = "Azuregos",
		[RTB["Ysondre"]] = "Ysondre",
		[RTB["Taerar"]] = "Taerar",
		[RTB["Emeriss"]] = "Emeriss",
		[RTB["Lethon"]] = "Lethon",

--		[RTB["Shade of Taerar"] = "IGNORE",
--		[RTB["Spirit Shade"] = "IGNORE",
--		[RTB["Demented Druid Spirit"] = "IGNORE",

		[RTB["Kurinnaxx"]] = "Kurinnaxx",
		[RTB["General Rajaxx"]] = "General Rajaxx",
		[RTB["Ayamiss the Hunter"]] = "Ayamiss the Hunter",
		[RTB["Buru the Gorger"]] = "Buru the Gorger",
		[RTB["Moam"]] = "Moam",
		[RTB["Ossirian the Unscarred"]] = "Ossirian the Unscarred",
--		[RTB["Buru Egg"] = "IGNORE",
--		[RTB["Canal Frenzy"] = "IGNORE",
--		[RTB["Mana Fiend"] = "IGNORE",
--		[RTB["Silicate Feeder"] = "IGNORE",
--		[RTB["Hive'Zara Hatchling"] = "IGNORE",
--		[RTB["Hive'Zara Larva"] = "IGNORE",
--		[RTB["Vekniss Hatchling"] = "IGNORE",
--		[RTB["Anubisath Warrior"] = "IGNORE",

		[RTB["The Prophet Skeram"]] = "The Prophet Skeram",
		[RTB["Fankriss the Unyielding"]] = "Fankriss the Unyielding",
		[RTB["Battleguard Sartura"]] = "Battleguard Sartura",
		[RTB["Princess Huhuran"]] = "Princess Huhuran",
		[RTB["Emperor Vek'lor"]] = "The Twin Emperors",
		[RTB["Emperor Vek'nilash"]] = "The Twin Emperors",
		[RTB["C'Thun"]] = "C'Thun",
		[RTB["Vem"]] = "Vem",
		[RTB["Princess Yauj"]] = "Princess Yauj",
		[RTB["Lord Kri"]] = "Lord Kri",
		[RTB["Viscidus"]] = "Viscidus",
		[RTB["Ouro"]] = "Ouro",
--		[RTB["Ouro Scarab"] = "IGNORE",
--		[RTB["Spawn of Fankriss"] = "IGNORE",
--		[RTB["Qiraji Scorpion"] = "IGNORE",
--		[RTB["Qiraji Scarab"] = "IGNORE",
--		[RTB["Vile Scarab"] = "IGNORE",
--		[RTB["Yauj Brood"] = "IGNORE",
--		[RTB["Sartura's Royal Guard"] = "IGNORE",
--		[RTB["Sartura's Royal Guard"] = "IGNORE",
--		[RTB["Poison Cloud"] = "IGNORE",
--		[RTB["Vekniss Drone"] = "IGNORE",
--		[RTB["Glob of Viscidus"] = "IGNORE",

--		[RTB["Spotlight"] = "IGNORE",
---		[RTB["Roach"] = "IGNORE",
--		[RTB["Snake"] = "IGNORE",
--		[RTB["Brown Snake"] = "IGNORE",
--		[RTB["Crimson Snake"] = "IGNORE",
--		[RTB["Black Kingsnake"] = "IGNORE",
--		[RTB["Beetle"] = "IGNORE",
--		[RTB["Dupe Bug"] = "IGNORE",
--		[RTB["Fire Beetle"] = "IGNORE",
--		[RTB["Scorpion"] = "IGNORE",
--		[RTB["Frog"] = "IGNORE",
--		[RTB["Hooktooth Frenzy"] = "IGNORE",
--		[RTB["Sacrificed Troll"] = "IGNORE",
--		[RTB["Spider"] = "IGNORE",
--		[RTB["Rat"] = "IGNORE",
--		[RTB["Jungle Toad"] = "IGNORE",
--		[RTB["Field Repair Bot 74A"] = "IGNORE",

		-- TBC
		--Karazhan
		[RTB["Doom Lord Kazzak"]] = "Doom Lord Kazzak",
		[RTB["Doomwalker"]] = "Doomwalker",
		[RTB["Attumen the Huntsman"]] = "Attumen the Huntsman",
--		[RTB["Dorothee"] = "IGNORE",
		[RTB["Maiden of Virtue"]] = "Maiden of Virtue",
--		[RTB["Midnight"] = "IGNORE",
		[RTB["Moroes"]] = "Moroes",
--		[RTB["Baron Rafe Dreuger"] = "IGNORE", -- Moroes add
--		[RTB["Baroness Dorothea Millstipe"] = "IGNORE", -- Moroes add
--		[RTB["Lady Catriona Von'Indi"] = "IGNORE", -- Moroes add
--		[RTB["Lady Keira Berrybuck"] = "IGNORE", -- Moroes add
--		[RTB["Lord Crispin Ference"] = "IGNORE", -- Moroes add
--		[RTB["Lord Robin Daris"] = "IGNORE", -- Moroes add
		[RTB["Netherspite"]] = "Netherspite",
		[RTB["Nightbane"]] = "Nightbane",
		[RTB["Prince Malchezaar"]] = "Prince Malchezaar",
		[RTB["Shade of Aran"]] = "Shade of Aran",
--		[RTB["Strawman"] = "IGNORE",
		[RTB["Terestian Illhoof"]] = "Terestian Illhoof",
--		[RTB["Kil'rek"] = "IGNORE",
--		[RTB["The Big Bad Wolf"]] = "The Big Bad Wolf",
--		[RTB["The Crone"]] = "The Crone",
		[RTB["The Curator"]] = "The Curator",
--		[RTB["Tinhead"] = "IGNORE",
--		[RTB["Tito"] = "IGNORE",
		[RTB["Rokad the Ravager"]] = "Rokad the Ravager",
		[RTB["Hyakiss the Lurker"]] = "Hyakiss the Lurker",
		[RTB["Shadikith the Glider"]] = "Shadikith the Glider",
		[RTB["Chess Event"]] = "Chess Event",
--		[RTB["Julianne"]] = "Romulo and Julianne",
--		[RTB["Roar"] = "IGNORE",
--		[RTB["Romulo"] = "IGNORE",
--		[RTB["Echo of Medivh"]] = "Echo of Medivh",
--		[RTB["Image of Medivh"]] = "Image of Medivh",
		-- Zul'Aman
		[RTB["Nalorakk"]] = "Nalorakk",	
		[RTB["Akil'zon"]] = "Akil'zon",	
		[RTB["Jan'alai"]] = "Jan'alai",	
		[RTB["Halazzi"]] = "Halazzi",	
--		[RTB["Witch Doctor"]] = "Witch Doctor",	
		[RTB["Hex Lord Malacrass"]] = "Hex Lord Malacrass",	
		[RTB["Zul'jin"]] = "Zul'jin",	
		--Gruul
		[RTB["High King Maulgar"]] = "High King Maulgar",
		[RTB["Gruul the Dragonkiller"]] = "Gruul the Dragonkiller",
--		[RTB["Blindeye the Seer"] = "IGNORE",
--		[RTB["Kiggler the Crazed"] = "IGNORE",
--		[RTB["Krosh Firehand"] = "IGNORE",
--		[RTB["Olm the Summoner"] = "IGNORE",
		-- Magtheridon
		[RTB["Magtheridon"]] = "Magtheridon",
--		[RTB["Hellfire Warder"] = "IGNORE",
--		[RTB["Hellfire Channeler"] = "IGNORE",
		--Serpentshrine Cavern
		[RTB["Hydross the Unstable"]] = "Hydross the Unstable",
		[RTB["The Lurker Below"]] = "The Lurker Below",
		[RTB["Leotheras the Blind"]] = "Leotheras the Blind",
		[RTB["Fathom-Lord Karathress"]] = "Fathom-Lord Karathress",
		[RTB["Morogrim Tidewalker"]] = "Morogrim Tidewalker",
		[RTB["Lady Vashj"]] = "Lady Vashj",
		-- Bossadds
			-- Hydross Adds
--		[RTB["Pure Spawn of Hydross"] = "IGNORE", -- Pure Spawn of Hydross
--		[RTB["Tainted Spawn of Hydross"] = "IGNORE", -- Tainted Spawn of Hydross
--		[RTB["Tainted Water Elemental"] = "IGNORE", -- Tainted Water Elemental
--		[RTB["Purified Water Elemental"] = "IGNORE", -- Purified Water Elemental  

		-- Morogrim Adds
--		[RTB["Tidewalker Lurker"] = "IGNORE", -- Tidewalker Lurker
--		[RTB["Water Globule"] = "IGNORE", -- Water Globule (Waterbubbles Tidewalker summons at 25%) 

		-- Fathom-Lord Karathress Adds
--		[RTB["Spitfire Totem"] = "IGNORE", -- Spitfire Totem
--		[RTB["Greater Earthbind Totem"] = "IGNORE", -- Greater Earthbind Totem
--		[RTB["Greater Poison Cleansing Totem"] = "IGNORE", -- Greater Poison Cleansing Totem
--		[RTB["Fathom Lurker"] = "IGNORE", -- Fathom Lurker
--		[RTB["Fathom Sporebat"] = "IGNORE", -- Fathom Sporebat
--		[RTB["Fathom-Guard Caribdis"] = "IGNORE", -- Fathom-Guard Caribdis
--		[RTB["Fathom-Guard Tidalvess"] = "IGNORE", -- Fathom-Guard Tidalvess
--		[RTB["Fathom-Guard Sharkkis"] = "IGNORE", -- Fathom-Guard Sharkkis
		
		-- The Lurker Below Adds
--		[RTB["Coilfang Guardian"] = "IGNORE", -- Coilfang Guardian
--		[RTB["Coilfang Ambusher"] = "IGNORE", -- Coilfang Ambusher
		
		-- Leotheras the Blind Adds
--		[RTB["Inner Demon"] = "IGNORE", -- Inner Demon
		
		-- Vashj Adds
--		[RTB["Toxic Spore Bat"] = "IGNORE",  -- Toxic Spore Bat
--		[RTB["Tainted Elemental"] = "IGNORE", -- Tainted Elemental
--		[RTB["Coilfang Elite"] = "IGNORE", -- Coilfang Elite
--		[RTB["Coilfang Strider"] = "IGNORE", -- Coilfang Strider
--		[RTB["Enchanted Elemental"] = "IGNORE", -- Enchanted Elemental			
		-- SSC Trashmobs 
--		[RTB["Coilfang Beast-Tamer"] = "IGNORE",	-- Coilfang Beast-Tamer
--		[RTB["Vashj'ir Honor Guard"] = "IGNORE",	-- Vashj'ir Honor Guard
--		[RTB["Greyheart Tidecaller"] = "IGNORE", -- Greyheart Tidecaller
--		[RTB["Tidewalker Harpooner"] = "IGNORE", -- Tidewalker Harpooner
--		[RTB["Coilfang Hate-Screamer"] = "IGNORE", -- Coilfang Hate-Screamer
--		[RTB["Tidewalker Warrior"] = "IGNORE", -- Tidewalker Warrior
--		[RTB["Serpentshrine Lurker"] = "IGNORE", -- Serpentshrine Lurker
--		[RTB["Greyheart Nether-Mage"] = "IGNORE", -- Greyheart Nether-Mage
--		[RTB["Coilfang Priestess"] = "IGNORE", -- Coilfang Priestess
--		[RTB["Tidewalker Shaman"] = "IGNORE", -- Tidewalker Shaman
--		[RTB["Greyheart Shield-Bearer"] = "IGNORE", -- Greyheart Shield-Bearer
--		[RTB["Coilfang Serpentguard"] = "IGNORE", -- Coilfang Serpentguard
--		[RTB["Greyheart Skulker"] = "IGNORE", -- Greyheart Skulker
--		[RTB["Serpentshrine Sporebat"] = "IGNORE", -- Serpentshrine Sporebat
--		[RTB["Greyheart Technician"] = "IGNORE", -- Greyheart Technician
--		[RTB["Coilfang Fathom-Witch"] = "IGNORE", -- Coilfang Fathom-Witch
--		[RTB["Tidewalker Depth-Seer"] = "IGNORE", -- Tidewalker Depth-Seer
--		[RTB["Underbog Colossus"] = "IGNORE", -- Underbog Colossus
--		[RTB["Tidewalker Hydromancer"] = "IGNORE", -- Tidewalker Hydromancer
--		[RTB["Coilfang Shatterer"] = "IGNORE", -- Coilfang Shatterer
		-- SSC Trashmobs without loot
--		[RTB["Coilfang Frenzy"] = "IGNORE", -- Coilfang Frenzy
--		[RTB["Serpentshrine Tidecaller"] = "IGNORE", -- Serpentshrine Tidecaller
--		[RTB["Colossus Lurker"] = "IGNORE", -- Colossus Lurker
--		[RTB["Colossus Rager"] = "IGNORE", -- Colossus Rager
--		[RTB["Serpentshrine Parasite"] = "IGNORE", -- Serpentshrine Parasite
--		[RTB["Underbog Mushroom"] = "IGNORE", -- Underbog Mushroom
--		[RTB["Water Elemental Totem"] = "IGNORE", -- Water Elemental Totem
--		[RTB["Greyheart Spellbinder"] = "IGNORE", -- Greyheart Spellbinder
--		[RTB["Priestess Spirit"] = "IGNORE", -- Priestess Spirit	
		--Black Temple
		[RTB["High Warlord Naj'entus"]] = "High Warlord Naj'entus",
		[RTB["Supremus"]] = "Supremus",
		[RTB["Gurtogg Bloodboil"]] = "Gurtogg Bloodboil",
		[RTB["Teron Gorefiend"]] = "Teron Gorefiend",
		[RTB["Shade of Akama"]] = "Shade of Akama",
		[RTB["Essence of Anger"]] = "Reliquary of Souls",
		[RTB["Mother Shahraz"]] = "Mother Shahraz",
		[RTB["Gathios the Shatterer"]] = "Illidari Council",
		[RTB["High Nethermancer Zerevor"]] = "Illidari Council",
		[RTB["Lady Malande"]] = "Illidari Council",
		[RTB["Veras Darkshadow"]] = "Illidari Council",	
		[RTB["Illidan Stormrage"]] = "Illidan Stormrage",	
		--Tempest Keep: The Eye
		[RTB["Al'ar"]] = "Al'ar",
		[RTB["High Astromancer Solarian"]] = "High Astromancer Solarian",	
		[RTB["Void Reaver"]] = "Void Reaver",
		[RTB["Kael'thas Sunstrider"]] = "Kael'thas Sunstrider",
		-- Bossadds
		-- Al'ar Adds
--		[RTB["Ember of Al'ar"] = "IGNORE", -- Ember of Al'ar
		-- Astromancer Adds
--		[RTB["Solarium Agent"] = "IGNORE", -- Solarium Agent
--		[RTB["Solarium Priest"] = "IGNORE", -- Solarium Priest
--		-- Kael'thas Adds
--		[RTB["Lord Sanguinar"] = "IGNORE", -- Lord Sanguinar
--		[RTB["Grand Astromancer Capernian"] = "IGNORE", -- Grand Astromancer Capernian  
--		[RTB["Master Engineer Telonicus"] = "IGNORE", -- Master Engineer Telonicus
--		[RTB["Phoenix Egg"] = "IGNORE", -- Phoenix Egg
--		[RTB["Phoenix"] = "IGNORE", -- Phoenix
--		[RTB["Thaladred the Darkener"] = "IGNORE", -- Thaladred the Darkener
--		-- Kael'thas Weapons
--		[RTB["Infinity Blades"] = "IGNORE", -- Infinity Blades
--		[RTB["Cosmic Infuser"] = "IGNORE", -- Cosmic Infuser
--		[RTB["Netherstrand Longbow"] = "IGNORE", -- Netherstrand Longbow
--		[RTB["Phaseshift Bulwark"] = "IGNORE", -- Phaseshift Bulwark
--		[RTB["Staff of Disintegration"] = "IGNORE", -- Staff of Disintegration
--		[RTB["Devastation"] = "IGNORE", -- Devastation
--		[RTB["Warp Slicer"] = "IGNORE", -- Warp Slicer
		-- TK Trash
--		[RTB["Astromancer"] = "IGNORE", -- Astromancer
---		[RTB["Astromancer Lord"] = "IGNORE", -- Astromancer Lord
--		[RTB["Novice Astromancer"] = "IGNORE", -- Novice Astromancer
--		[RTB["Crimson Hand Blood Knight"] = "IGNORE", -- Crimson Hand Blood Knight
--		[RTB["Tempest Falconer"] = "IGNORE", -- Tempest Falconer
--		[RTB["Crimson Hand Inquisitor"] = "IGNORE", -- Crimson Hand Inquisitor
--		[RTB["Crimson Hand Battle Mage"] = "IGNORE", -- Crimson Hand Battle Mage
--		[RTB["Bloodwarder Squir"] = "IGNORE", -- Bloodwarder Squire
--		[RTB["Crystalcore Mechanic"] = "IGNORE", -- Crystalcore Mechanic
--		[RTB["Crystalcore Sentinel"] = "IGNORE", -- Crystalcore Sentinel
--		[RTB["Crystalcore Devastator"] = "IGNORE", -- Crystalcore Devastator
--		[RTB["Bloodwarder Legionnaire"] = "IGNORE", -- Bloodwarder Legionnaire
--		[RTB["Bloodwarder Marshal"] = "IGNORE", -- Bloodwarder Marshal
--		[RTB["Nether Scryer"] = "IGNORE", -- Nether Scryer
--		[RTB["Phoenix-Hawk Hatchlings"] = "IGNORE", -- Phoenix-Hawk Hatchling
--		[RTB["Phoenix-Hawk"] = "IGNORE", -- Phoenix-Hawk
--		[RTB["Tempest-Smith"] = "IGNORE", -- Tempest-Smith
---		[RTB["Star Scryer"] = "IGNORE", -- Star Scryer
--		[RTB["Apprentice Star Scryer"] = "IGNORE", -- Apprentice Star Scryer
--		[RTB["Bloodwarder Vindicator"] = "IGNORE", -- Bloodwarder Vindicator
--		[RTB["Crimson Hand Centurion"] = "IGNORE", -- Crimson Hand Centurion
--
		[RTB["Illidan Stormrage"]] = "Illidan Stormrage",
--		[RTB["Highlord Kruul"]] = "Highlord Kruul",	

		--Battle of Mount Hyjal
		[RTB["Rage Winterchill"]] = "Rage Winterchill",
		[RTB["Anetheron"]] = "Anetheron",
		[RTB["Kaz'rogal"]] = "Kaz'rogal",
		[RTB["Azgalor"]] = "Azgalor",
		[RTB["Archimonde"]] = "Archimonde",

		--Sunwell Plateau
--		[RTB["Kalecgos"] =  "IGNORE", -- Kalecgos
		[RTB["Sathrovarr the Corruptor"]] = "Sathrovarr the Corruptor",
		[RTB["Sathrovarr the Corruptor"]] = "Kalecgos",
		[RTB["Brutallus"]] = "Brutallus",
--		[RTB["Madrigosa"] = "IGNORE", -- Madrigosa	
		[RTB["Felmyst"]] = "Felmyst",
		[RTB["Lady Sacrolash"]] = "The Eredar Twins",
		[RTB["Grand Warlock Alythess"]] = "The Eredar Twins",
		[RTB["Entropius"]] = "Entropius",
		[RTB["Kil'jaeden"]] = "Kil'jaeden",	
--		[RTB["M'uru"] = "IGNORE",
--		[RTB["Shadowsword Berserker"] = "IGNORE", -- Shadowsword Berserker
--		[RTB["Shadowsword Fury Mage"] = "IGNORE", -- Shadowsword Fury Mage
--		[RTB["Void Sentinel"] = "IGNORE", -- Void Sentinel
--		[RTB["Void Spawn"] = "IGNORE", -- Void Spawn

--		Ragefire Chasm
--		[RTB["Oggleflint"]] = "Oggleflint",
--		[RTB["Taragaman the Hungerer"]] = "Taragaman the Hungerer",
--		[RTB["Jergosh the Invoker"]] = "Jergosh the Invoker",
--		[RTB["Bazzalan"]] = "Bazzalan",
--		-- halls
--		[RTB["Grand Warlock Nethekurse"]] = "Grand Warlock Nethekurse",
--		[RTB["Blood Guard Porung"]] = "Blood Guard Porung",
--		[RTB["Warbringer O'mrogg"]] = "Warbringer O'mrogg",
--		[RTB["Warchief Kargath Bladefist"]] = "Warchief Kargath Bladefist",
--		--tdm
--		[RTB["Selin Fireheart"]] = "Selin Fireheart",
--		[RTB["Vexallus"]] = "Vexallus",
--		[RTB["Priestess Delrissa"]] = "Priestess Delrissa",
--		[RTB["Kael'thas Sunstrider"]] = "Kael'thas Sunstrider",
--
--		["Schwarze Ratte"] = "Schwarze Ratte",
		["Skorpion"] = "Skorpionmima",	-- Testing
		["Wildes Drachenfalkenjunges"] = "Drachenfalkhfhfhen",	

		["DEFAULTBOSS"] = "Trash mob",
		["Track Members"] = "Track Members",
--};
--	CT_RaidTracker_lang_BossKills = {
		["Marlow"] = "Huhn",
		["Marlow1"] = "jhdsjkfh",
};