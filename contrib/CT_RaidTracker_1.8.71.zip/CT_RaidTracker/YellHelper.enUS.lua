local GAME_LOCALE = GetLocale();

if (GAME_LOCALE == "enUS") or (GAME_LOCALE == "enGB") then
local RTB = LibStub( "LibBabble-Boss-3.0" ):GetLookupTable();
CT_RaidTracker_lang_BossKills = {
	["I grow tired of these games. Proceed, and I will banish your souls to oblivion!"] = RTB["The Four Horsemen"], -- Four Horsemen
	["It would appear that I've made a slight miscalculation. I allowed my mind to be corrupted by the fiend in the prison, overriding my primary directive. All systems seem to be functional now. Clear."] = RTB["Mimiron"],
	["I...have...failed..."] = RTB["Ignis the Furnace Master"],
	["His hold on me dissipates. I can see clearly once more. Thank you, heroes."] = RTB["Freya"],
	["Stay your arms! I yield!"] = RTB["Thorim"],
	["I... I am released from his grasp... at last."] = RTB["Hodir"],
--	["Master, they come..."] = RTB["Kologarn"],
--	["You are bad... Toys... Very... Baaaaad!"] = RTB["XT-002 Deconstructor"],
--	["Mwa-ha-ha-ha! Oh, what horrors await you?"] = RTB["General Vezax"],
	["Your fate is sealed. The end of days is finally upon you and ALL who inhabit this miserable little seedling! Uulwi ifis halahs gag erh'ongg w'ssh."] = RTB["Yogg-Saron"],
	["Impossible..."] = RTB["Assembly of Iron"], -- Iron Council Hardmode / Steelbreaker last
	["You rush headlong into the maw of madness!"] = RTB["Assembly of Iron"], -- Iron Council Normalmode / Brundir last
	["What have you gained from my defeat? You are no less doomed, mortals!"] = RTB["Assembly of Iron"], -- Iron Council Semimode / Molgeim last
	-- Ulduar
	-- Trial of the Crusader
	["The Scourge cannot be stopped..."] = RTB["The Twin Val'kyr"],
 	["I have failed you, master..."] = RTB["Anub'arak"],
 	["A shallow and tragic victory. We are weaker as a whole from the losses suffered today. Who but the Lich King could benefit from such foolishness? Great warriors have lost their lives. And for what? The true threat looms ahead - the Lich King awaits us all in death."] = RTB["Faction Champions"],
	-- Trial of the Crusader
	-- Icecrown Citadel
	["The Alliance falter. Onward to the Lich King!"] = RTB["Icecrown Gunship Battle"], -- Gunship Battle Horde
	["Don't say I didn't warn ya, scoundrels! Onward, brothers and sisters!"] = RTB["Icecrown Gunship Battle"], -- Gunship Alliance

	["My queen, they... come."] = RTB["Blood Prince Council"], -- Blood Prince Council
	["I AM RENEWED! Ysera grant me the favor to lay these foul creatures to rest!"] = RTB["Valithria Dreamwalker"], -- Valithria Dreamwalker
	["They cannot fear..."] = RTB["The Lich King"], -- Lich King
	["Is it truly righteousness that drives you? I wonder..."] = RTB["The Lich King"], -- Lich King
	-- Icecrown Citadel

	-- Ruby Sanctum
	["Relish this victory, mortals, for it will be your last. This world will burn with the master's return!"] = RTB["Halion"],
--may bee like to change
	["Impossible! Stay your attack, mortals... I submit! I submit!"] = RTB["Majordomo Executus"],
--	CT_RaidTracker_lang_BossKills_Ignore_Razorgore_Yell = "I'm free!  That device shall never torment me again!";
--	CT_RaidTracker_lang_BossKills_Chess_Event_Yell = "Als sich der Fluch, der auf den T\195\188ren der Halle der Spiele lastete, l\195\182st, beginnen die Mauern von Karazhan zu beben."; -- need english translation
--	CT_RaidTracker_lang_BossKills_Chess_Event_BossName = "Chess Event";
	--
	["O happy dagger! This is thy sheath; there rust, and let me die!"] = RTB["Opera Event"],
--	CT_RaidTracker_lang_BossKills_Julianne_BossName = "Julianne";
	["I'm... never on... the losing... side..."]= RTB["Sathrovarr the Corruptor"],
  
-- Throne of the Four Winds
        ["The Conclave of Wind has dissipated. Your honorable conduct and determination have earned you the right to face me in battle, mortals. I await your assault on my platform! Come!"] = RTB["Conclave of Wind"], -- Conclave of Wind
-- Firelands
        ["Too soon! ... You have come too soon..."] = RTB["Ragnaros"],
};
end;