
local RTL = LibStub("AceLocale-3.0"):NewLocale("CT_RaidTracker", "enUS", true)
if( RTL ) then
RTL["View Raid"] = true;
RTL["View Loot"] = true;
RTL["View Players"] = true;
RTL["View Events"] = true;
RTL["Back"] = true;
RTL["View Items"] = true;
RTL["End"] = true;
RTL["New"] = true;
RTL["Snapshot"] = true;
RTL["Delete"] = true;
RTL["Click to Delete"] = true;
RTL["Add Event"] = true;
RTL["Left-click to toggle the raidlog browser"] = true;
RTL["Right-click to open the options menu"] = true;
RTL["Show/Hide CTRT"] = true;
RTL["Open/Close Options"] = true;
RTL["Add Events"] = true;
RTL["Add Custom Events"] = true;
RTL["Add Wipe Event"] = true;
RTL["Open/Close Item Options"] = true;
RTL["Events"] = true;
RTL["Player"] = true;

--not exist in zones and bosse Lib babble

		RTL["Battle of Mount Hyjal"] = true;
		RTL["Baradin Hold"] = true;
		RTL["Blackwing Descent"] = true;
		RTL["Throne of the Four Winds"] = true;
		RTL["The Bastion of Twilight"] = true;

--		operea event
--		RTL["Oz"] = true;
--		RTL["The Crone"] = true;
--		RTL["The Big Bad Wolf"] = true;
--		RTL["Romulo and Julianne"] = true;
--		Bradin
		RTL["Argaloth"] = true;					--[47120]
		-- Blackwing Descent
		RTL["Magmaul"] = true;					-- Magmaw missing
		RTL["Omnitron Defense System"] = true;		--[42180]	-- ID of Toxitron   - Omnitron Defense System may need bossyell
		RTL["Maloriak"] = true;					--[41378]
		RTL["Atramedes"] = true;				--[41442] 
		RTL["Chimaeron"] = true;				--[43296]
		RTL["Nefarian"] = true;					--[41376] 

		-- The Bastion of Twilight
		RTL["Valiona and Theralion"] = true;		--[45992]	-- ID of Valiona    - Valiona & Theralion - Twin drakes with shared health pool - may need boss yell
		RTL["Halfus Wyrmbreaker"] = true;			--[44600]
		RTL["Ascendant Council"] = true;			--[43735]	-- ID of Elementium Monstrosity
		RTL["Cho'gall"] = true;					--[43324] 

		-- Throne of the Four Winds
		RTL["Conclave of Wind"] = true;			--[45871]	-- ID of Nezir      - Conclave of Wind may need a bossyell (mobs are probably too far away to each other)
		RTL["Al'Akir"] = true;					--[46753]
end;

local RTL = LibStub("AceLocale-3.0"):NewLocale("CT_RaidTracker", "deDE")
if( RTL ) then
RTL["View Raid"] = "Zeige Raid";
RTL["View Loot"] = "Zeige Loot";
RTL["View Players"] = "Zeige Spieler";
RTL["View Events"] = "Zeige Ereignisse";
RTL["Back"] = "Zur\195\188ck";
RTL["View Items"] = "Zeige Items";
RTL["End"] = "Ende";
RTL["New"] = "Neu";
RTL["Snapshot"] = "Schnappschuss";
RTL["Delete"] = "L\195\182schen";
RTL["Click to Delete"] = "Zum L\195\182schen klicken";
RTL["Add Event"] = "Ereigniss hinzuf\195\188gen";
RTL["Left-click to toggle the raidlog browser"] = "Links klick zeige/verstecke CTRT";
RTL["Right-click to open the options menu"] = "Rechts klick zeige/verstecke Einstellungsmen\195\188";
RTL["Show/Hide CTRT"] = "Zeige/Verstecke CTRT";
RTL["Open/Close Options"] = "\195\150ffne/Schleisse Einstellungen";
RTL["Open/Close Item Options"] = "\195\150ffne/Schleisse Item Einstellungen";
RTL["Add Events"] = "Ereignis zuf\195\188egen";
RTL["Add Custom Event"] = "Eigenes Ereignis zuf\195\188gen";
RTL["Add Wipe Event"] = "F\195\188ge Raid Tot Hinzu";
RTL["Events"] = "Ereignisse";
RTL["Player"] = "Spieler";
--}
--Not listets in Babbles Zones
		RTL["Battle of Mount Hyjal"] = "Die Schlacht um den Berg Hyjal";
		RTL["Baradin Hold"] = "Baradinfestung";
		RTL["Blackwing Descent"] = "Pechschwingenabstieg";
		RTL["Throne of the Four Winds"] = "Thron der vier Winde";
		RTL["The Bastion of Twilight"] = "Bastion des Zwielichts";
--};



--		RTL["Oz"] ="Oz";
--		RTL["The Crone"] = "The Crone";
--		RTL["The Big Bad Wolf"] = "The Big Bad Wolf";
--		RTL["Romulo and Julianne"] = "Romulo und Julianne";
--		RTL["Eredar Twins"] = "Eredar Zwillinge";
--		BWD
--		RTL["Omnotron Defense System"] = "Omnotron Defense System";
--		RTL["Magmaul"] = "Magmaul";
--		RTL["Maloriak"] = "Maloriak";
--		Bradin
--		RTL["Argaloth"] = "Argaloth";
--		RTL["Eredar Twins"] = "Eredar Twins";
end;

if (GetLocale() == "enUS") then 

CT_ITEMREG = "(|c(%x+)|Hitem:([-%d:]+)|h%[(.-)%]|h|r)%";
CT_ITEMREG_MULTI = "(|c(%x+)|Hitem:([-%d:]+)|h%[(.-)%]|h|r)x(%d+)%";
CT_RaidTracker_lang_LeftGroup = "([^%s]+) has left the raid group";
CT_RaidTracker_lang_JoinedGroup = "([^%s]+) has joined the raid group";
CT_RaidTracker_lang_ReceivesLoot1 = "([^%s]+) receives loot: "..CT_ITEMREG..".";
CT_RaidTracker_lang_ReceivesLoot2 = "You receive loot: "..CT_ITEMREG..".";
CT_RaidTracker_lang_ReceivesLoot3 = "([^%s]+) receives loot: "..CT_ITEMREG_MULTI..".";
CT_RaidTracker_lang_ReceivesLoot4 = "You receive loot: "..CT_ITEMREG_MULTI..".";
CT_RaidTracker_lang_ReceivesLootYou = "You";

elseif (GetLocale() == "deDE") then
	CT_ITEMREG = "(|c(%x+)|Hitem:([-%d:]+)|h%[(.-)%]|h|r)%";
	CT_ITEMREG_MULTI = "(|c(%x+)|Hitem:([-%d:]+)|h%[(.-)%]|h|r)x(%d+)%";
	CT_RaidTracker_lang_LeftGroup = "([^%s]+) hat die Schlachtgruppe verlassen.";
	CT_RaidTracker_lang_JoinedGroup = "([^%s]+) hat sich der Schlachtgruppe angeschlossen.";
	CT_RaidTracker_lang_ReceivesLoot1 = "([^%s]+) bekommt Beute: "..CT_ITEMREG..".";
	CT_RaidTracker_lang_ReceivesLoot2 = "Ihr erhaltet Beute: "..CT_ITEMREG..".";
	CT_RaidTracker_lang_ReceivesLoot3 = "([^%s]+) erh\195\164lt Beute: "..CT_ITEMREG_MULTI..".";
	CT_RaidTracker_lang_ReceivesLoot4 = "Ihr erhaltet Beute: "..CT_ITEMREG_MULTI..".";
	CT_RaidTracker_lang_ReceivesLootYou = "Ihr";

elseif (GetLocale() == "frFR") then

   CT_RaidTracker_lang_LeftGroup = "([^%s]+) a quitt\195\169 le groupe de raid";
   CT_RaidTracker_lang_JoinedGroup = "([^%s]+) a rejoint le group de raid";
   CT_RaidTracker_lang_ReceivesLoot1 = "([^%s]+) re\195\167oit le butin.+: "..CT_ITEMREG..".";
   CT_RaidTracker_lang_ReceivesLoot2 = "Vous recevez le butin.+: "..CT_ITEMREG..".";
   CT_RaidTracker_lang_ReceivesLoot3 = "([^%s]+) re\195\167oit le butin.+: "..CT_ITEMREG_MULTI..".";
   CT_RaidTracker_lang_ReceivesLoot4 = "Vous recevez le butin.+: "..CT_ITEMREG_MULTI..".";
   CT_RaidTracker_lang_ReceivesLootYou = "Vous";

elseif (GetLocale() == "esES" or (GetLocale() == "esMX")) then

	CT_RaidTracker_lang_LeftGroup = "([^%s]+) se ha marchado de la banda."; 
	CT_RaidTracker_lang_JoinedGroup = "([^%s]+) se ha unido a la banda."; 
	CT_RaidTracker_lang_ReceivesLoot1 = "([^%s]+) recibe el bot\195\173n: "..CT_ITEMREG.."."; 
	CT_RaidTracker_lang_ReceivesLoot2 = "Recibes bot\195\173n: "..CT_ITEMREG.."."; 
	CT_RaidTracker_lang_ReceivesLoot3 = "([^%s]+) recibe el bot\195\173n: "..CT_ITEMREG_MULTI.."."; 
	CT_RaidTracker_lang_ReceivesLoot4 = "Recibes bot\195\173n: "..CT_ITEMREG_MULTI.."."; 
	CT_RaidTracker_lang_ReceivesLootYou = "Recibes";	
	
end;