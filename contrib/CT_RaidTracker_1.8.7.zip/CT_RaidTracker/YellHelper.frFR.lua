if (GetLocale() == "frFR") then
	local RTB = LibStub( "LibBabble-Boss-3.0" ):GetLookupTable();
   CT_RaidTracker_lang_BossKills = {
      -- citadelle
      ["Vous direz pas que j'vous avais pas pr�venus, canailles ! Mes fr�res et s�urs, en avant !"] = RTB["Icecrown Gunship Battle"],
      ["Vous direz pas que j'vous avais pas pr\195\169venus, canailles ! Mes fr\195\168res et s�urs, en avant !"] = RTB["Icecrown Gunship Battle"],
      -- Ulduar
      ["Il semblerait que j'aie pu faire une minime erreur de calcul. J'ai permis \195\160 mon esprit de se laisser corrompre par ce d\195\169mon dans la prison qui a d�sactiv\195\169 ma directive principale. Tous les syst\195\168mes fonctionnent \195\160 nouveau. Termin\195\169."] = RTB["Mimiron"],
--      ["J'ai... \195\169chou\195\169..."] = RTB["Ignis the Furnace Master"],
      ["Son emprise sur moi se dissipe. J'y vois \195\160 nouveau clair. Merci, H\195\169ros."] = RTB["Freya"],
      ["Retenez vos coups ! Je me rends !"] = RTB["Thorim"],
      ["Je suis... lib\195\169r\195\169 de son emprise... enfin."] = RTB["Hodir"],
--      ["Master, they come..."] = RTB["Kologarn"],
--      ["You are bad... Toys... Very... Baaaaad!"] = RTB["XT-002 Deconstructor"],
--      ["Mwa-ha-ha-ha! Oh, what horrors await you?"] = RTB["General Vezax"],
--      ["Votre destin est scell�. La fin des temps est enfin arriv�e pour vous et tous les habitants de ce mis�rable petit bourgeon. Uulwi ifis halahs gag erh'ongg w'ssh."] = RTB["Yogg-Saron"],
--      ["Impossible..."] = RTB["Assembly of Iron"], -- Iron Council Hardmode / Steelbreaker last
--      ["You rush headlong into the maw of madness!"] = RTB["Assembly of Iron"], -- Iron Council Normalmode / Brundir last
--      ["What have you gained from my defeat? You are no less doomed, mortals!"] = RTB["Assembly of Iron"], -- Iron Council Semimode / Molgeim last
      -- Ulduar
      -- Trial of the Crusader
--      ["Personne ne peut arr\195\170ter le Fl\195\169au�"] = RTB["Twin Val'kyr"],
--      ["I have failed you, master..."] = RTB["Anub'arak"],
--      ["GLOIRE � L'ALLIANCE !"] = RTB["Faction Champions"],
--      ["Une victoire tragique et d\195\169pourvue de sens. La perte subie aujourd'hui nous affaiblira tous, car qui d'autre que le roi-liche pourrait b\195\169n\195\169ficier d'une telle folie ? De grands guerriers ont perdu la vie. Et pour quoi ? La vraie menace plane \195\160 l'horizon : le roi-liche nous attend, tous, dans la mort."] = RTB["Faction Champions"],
   };

end;